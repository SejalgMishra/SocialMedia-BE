const mongoose = require('mongoose')

const postSchema = new mongoose.Schema({
    content: String,
    images: {
        type: Array,
        required: true
    },
    likes: [{ type: mongoose.Types.ObjectId, ref: 'users' }],
    comments: [{ type: mongoose.Types.ObjectId, ref: 'comments' }],
    user: {type: mongoose.Types.ObjectId, ref: 'users'}
}, {
    timestamps: true
})

module.exports = mongoose.model('post', postSchema)