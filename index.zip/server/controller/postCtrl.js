const postSchema = require("../model/postModel");

class postCtrl {
  static createPost = async (req, res) => {
    try {
      const { content, images } = req.body;

      const newPosts = await postSchema.create({
        content,
        images,
        user: req.user._id,
      });
      res.json({ msg: "post created", newPosts, user: req.user._id });
    } catch (error) {
      console.error(error);
      res.status(500).send("Server Error");
    }
  };

  static getPost = async (req, res) => {
    try {
      console.log(req.user);
      const posts = await postSchema.find({user : [...req.user.following , req.user._id ]}).populate("user likes" , "avatar username fullname" )
      res.json({ msg : "success" , posts ,})
    } catch (error) {
      console.error(error);
      res.status(500).send("Server Error");
    }
  };
}

module.exports = postCtrl;
