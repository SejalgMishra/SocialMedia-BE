const auth = require("../../middleware/auth")
const postCtrl = require("../controller/postCtrl")

const express = require ("express")

const router = express.Router()

router.post("/post" , auth , postCtrl.createPost)

router.get("/post" , auth , postCtrl.getPost)


module.exports = router